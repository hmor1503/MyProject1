import java.util.Scanner;

public class Room3 {
    public static void main(String[] args) {
        System.out.println("AS YOU VENTURE IN THE THIRD ROOM, YOU ARE STOPPED BY A MENACING TROLL");
        System.out.println("Troll: HALT! YOU DARE TO TRY TO ESCAPE THIS DUNGEON!? YOU MUST DIE.");
        Scanner sc = new Scanner(System.in);
        System.out.println("To negotiate with Troll, enter 'NEGOTIATE'. To kill Troll, enter 'KILL'." +
                " To put Troll in bag, enter 'INVENTORY'");
        String troll = sc.nextLine();
        if (troll.equals("NEGOTIATE")) {
            System.out.println("Troll: 'YOUR WORDS DO NOT SWAY ME, HUMAN. YOU WILL PERISH LIKE THE REST WHO TRY TO ESCAPE'\nTHE TROLL SWINGS HIS CLUB ONTO YOUR HEAD CONCAVING YOUR SKULL KILLING YOU INSTANTLY. GAME OVER.");
        } else if (troll.equals("KILL")) {
            System.out.println("YOU PIERCE YOUR SWORD RIGHT THROUGH THE TROLL’S HEART \n Troll: “I REGRET NOTHING” \n THE TROLL PERISHES IN FRONT OF YOU. YOU MAY NOW PROCEED FORWARD!");
        } else if (troll.equals("INVENTORY")) {
            System.out.println("Troll: “HEY! WHAT THE HELL ARE YOU DOING! STOP THAT! THE TROLL YELLS”\nYOU WEREN’T SUPPOSED TO DO THAT. I DON’T KNOW HOW YOU GOT A TROLL" +
                    " IN YOUR BAG BUT LET’S ROLL WITH IT.");
        } else {
            System.out.println("PLEASE ENTER A VALID RESPONSE");
        }
    }
}
