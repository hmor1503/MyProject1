public class MechanicRNG {
    public static void main(String[] args) {

        int number;
        number = (int) (Math.random() * 100);

        if (number > 75) {
            System.out.println("“You will not take any chances with riddles and use your trusty sword to guide you.\n " +
                    "You lunge towards the giant worm and slice right down its body before it could fight back, killing it.\n " +
                    "A door opens at the other side of the room leading to the exit. Winner!”");
        } else {
            System.out.println("“You will not take any chances with riddles and use your trusty sword to guide you.\n " +
                    "As you sprint towards the worm in an attempt to slay it. The giant worm sees through your plan and swallows you whole. Game Over.”");
        }
    }
}